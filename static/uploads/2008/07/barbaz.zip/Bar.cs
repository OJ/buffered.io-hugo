﻿namespace Bar
{
    public class Bar
    {
        private Baz.Baz _baz = new Baz.Baz();

        public string SecretMessage
        {
            get { return _baz.SecretMessage; }
        }
    }
}

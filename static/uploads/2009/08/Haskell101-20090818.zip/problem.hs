import Data.List (transpose)
import Control.Arrow ((&&&))

vals = [[150,200,45,57,95,2,45,32,15,10,5,2,2,4],
        [12,20,45,37,10,5,2,2,10,95,2,45,32,7],
        [32,15,10,5,2,23,24,15,20,45,57,95,0,45]]

extremes n = (b, s)
  where l = map sum $ transpose n
        b = maximum l
        s = minimum l

main = print $ extremes vals

extremes2 = (maximum &&& minimum) . map sum . transpose


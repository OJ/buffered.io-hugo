// -------------------------------------------------------------- //
//
/// \file MDIChildWindow.h
/// \brief Contains the declaration for a generic MDI window object.
/// Any window that is MDI used in the system should inherit from this
/// window type.
//
// $History: $
//    
// -------------------------------------------------------------- //

#ifndef _WIN32WINDOWMDICHILDWINDOW_H_
#define _WIN32WINDOWMDICHILDWINDOW_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Win32/Window/Window.h"

namespace Win32
{

    namespace Window
    {

        // forward declaration
        class MDIParentWindow;

        /// \ingroup Win32Window
        /// \brief Class that is a generic wrapper for window object.
        /// \remark The class contains a collection of functions that
        /// are functional for all types of windows. Any window objects
        /// that are to be created as part of the system should inherit
        /// from this class and overload the required functionality
        class MDIChildWindow : public Window
        {

            // mention that the WindowClass object is a friend so that it
            // can change the message proc depending on the type of window
            friend class Win32::Window::WindowClass;

        public: /// \name Destruction and cleanup
            /// @{

            /// \brief Object destructor.
            virtual ~MDIChildWindow(void);

            /// @}
        public: /// \name MDI Child access functions
            /// @{

            inline HWND GetClientHandle(void) const;

            /// @}
        public: /// \name Public Win32::Window::Window overloads
            /// @{

            virtual void Destroy(void);

            virtual bool Create(Window* parent = NULL);

            virtual HWND GetHandle(void) const;

            virtual TSTR GetCaption(void) const;

            virtual int GetLeft(void) const;

            virtual int GetTop(void) const;

            virtual int GetWidth(void) const;

            virtual int GetHeight(void) const;

            virtual void SetCaption(const TCHAR* const caption);

            virtual void AddWinStyle(LONG style);

            virtual void RemoveWinStyle(LONG style);

            virtual void AddExtWinStyle(LONG style);

            virtual void SetIcon(HICON icon);

            virtual void SetLeft(int left);

            virtual void SetTop(int top);

            virtual void SetWidth(int width);

            virtual void SetHeight(int height);

            virtual void MoveTo(int left, int top);

            virtual void Resize(int width, int height);

            virtual void Show(void);

            virtual void Hide(void);

            virtual void Minimise(void);

            virtual void Maximise(void);

            virtual void Close(void);

            /// @}
        protected: /// \name Object Construction
            /// @{

            /// \brief Object constructor
            MDIChildWindow(Win32::Application* application);

            /// @}
        protected: /// \name Protected Win32::Window::Window overloads
            /// @{

            virtual LRESULT Switch(UINT msg, WPARAM wParam, LPARAM lParam);

            virtual LRESULT Created(CREATESTRUCT* cs);

            virtual LRESULT DefProc(UINT msg, WPARAM wParam, LPARAM lParam);

            virtual bool Command(WORD controlID, WORD msg);

            virtual LRESULT Closed(void);

            virtual LRESULT Destroyed(void);

            /// @}
        protected: /// \name Callback functions/handlers
            /// @{

            /// \brief The main message bottleneck function for windows
            /// \param win Handle to the window receiving the message
            /// \param msg Message that has been sent to the window
            /// \param wParam Word parameter associated with the window
            /// \param lParam Long parameter associated with the window
            /// \return Varies depending the message and the result of processing
            /// \remark This single function is where every message for every type
            /// of MDI window in the application comes through. This function is
            /// responsible for determining the window object required, and passing
            /// the message on to that window's Switch() function. If no object
            /// is found associated with a window, then default processing occurs.
            /// \sa Switch()
            static LRESULT CALLBACK MessageProc(HWND win, UINT msg, WPARAM wParam, LPARAM lParam);

            /// @}
        private: /// \name Illegal functions
            /// @{

            /// \brief This function is not allowed to be used.
            MDIChildWindow(const MDIChildWindow& window);

            /// \brief This function is not allowed to be used.
            MDIChildWindow& operator=(const MDIChildWindow& window);

            /// @}
        private: /// \name Member variables
            /// @{

            /// \brief Handle to the window
            HWND m_Win;

            /// \brief Handle to the parent window
            MDIParentWindow* m_ParentWin;

            /// \brief The creation structure for the MDI child
            MDICREATESTRUCT m_CreateStruct;

            /// \brief Caption of the window
            TSTR m_Caption;

            /// @}
        };

    }

}

#endif // _WIN32WINDOWMDICHILDWINDOW_H_

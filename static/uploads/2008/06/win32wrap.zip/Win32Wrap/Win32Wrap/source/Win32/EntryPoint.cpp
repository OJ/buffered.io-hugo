// -------------------------------------------------------------- //
//
/// \file EntryPoint.cpp
/// \brief Contains namespace which holds the main handles for the
/// application, along with helper types, and class lists.
//
// -------------------------------------------------------------- //

#include "Win32/Window/WindowClassFactory.h"
#include "Win32/Application.h"

/// \brief This function is requried to be defined by the program that
/// is using this library.
extern int Win32Main(Win32::Application& theApplication);

/// \brief Windows entry point.
/// \param instance Handle to the application instance.
/// \param prevInstance Unused.
/// \param cmdLine Pointer to the command line string.
/// \param showCmd Value specifying how the window should be shown.
/// \return Integer value - usually zero.
/// \remark This function contains code that will set up a basic
/// Win32 environment and register some handles into the Handles
/// namespace so that they can be readily accessed from elsewhere.
/// \todo Change this so that it's not required for a DLL to work.
/// \todo Figure out why changing the entry point in UNICODE causes
/// the application to hang.
int WINAPI WinMain(HINSTANCE instance, HINSTANCE prevInstance, LPTSTR cmdLine, int showCmd)
{
    // create an application instance
    Win32::Application theApplication(instance, __argc, __targv);

    // invoke the entry point for the custom application.
    int result = Win32Main(theApplication);

    return result;
}

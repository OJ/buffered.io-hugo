{-# LANGUAGE NoMonomorphismRestriction #-}
import Data.List

sampleWords = ["elvis", "lives", "dod", "foo", "odd", "viles", "oof"]
acro = map (map snd) . groupBy (\x y -> fst x == fst y) . sort . map (\x -> (sort x, x))

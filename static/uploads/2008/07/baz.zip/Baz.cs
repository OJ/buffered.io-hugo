﻿namespace Baz
{
    public class Baz
    {
        public string SecretMessage
        {
            get { return "Zaphod Beeblebrox"; }
        }
    }
}

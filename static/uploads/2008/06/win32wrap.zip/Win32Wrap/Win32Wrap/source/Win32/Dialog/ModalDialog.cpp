// -------------------------------------------------------------- //
//
/// \file ModalDialog.h
/// \brief Contains the declaration for a generic dialog object.
/// Any dialog that is used in the system should inherit from this
/// dialog type
//
// -------------------------------------------------------------- //

#include "Win32/Dialog/ModalDialog.h"
#include "Win32/Application.h"

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Destroy
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::Destroy()
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::GetHandle
// -------------------------------------------------------------- //
HWND Win32::Dialog::ModalDialog::GetHandle() const
{
    return m_Dlg;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::GetCaption
// -------------------------------------------------------------- //
Win32::TSTR Win32::Dialog::ModalDialog::GetCaption() const
{
    return m_Caption;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::GetLeft
// -------------------------------------------------------------- //
int Win32::Dialog::ModalDialog::GetLeft() const
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::GetTop
// -------------------------------------------------------------- //
int Win32::Dialog::ModalDialog::GetTop() const
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::GetWidth
// -------------------------------------------------------------- //
int Win32::Dialog::ModalDialog::GetWidth() const
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::GetHeight
// -------------------------------------------------------------- //
int Win32::Dialog::ModalDialog::GetHeight() const
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::SetCaption
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::SetCaption(const TCHAR* const caption)
{
    m_Caption = caption;

    if(m_Dlg != NULL)
    {
        ::SetWindowText(m_Dlg, caption);
    }
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::AddWinStyle
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::AddWinStyle(LONG style)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::RemoveWinStyle
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::RemoveWinStyle(LONG style)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::AddExtWinStyle
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::AddExtWinStyle(LONG style)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::SetIcon
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::SetIcon(HICON icon)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::SetLeft
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::SetLeft(int left)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::SetTop
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::SetTop(int top)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::SetWidth
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::SetWidth(int width)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::SetHeight
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::SetHeight(int height)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::MoveTo
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::MoveTo(int left, int top)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Resize
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::Resize(int width, int height)
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Show
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::Show()
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Hide
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::Hide()
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Minimise
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::Minimise()
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Maximise
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::Maximise()
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Close
// -------------------------------------------------------------- //
void Win32::Dialog::ModalDialog::Close()
{
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Switch
// -------------------------------------------------------------- //
LRESULT Win32::Dialog::ModalDialog::Switch(UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
    case WM_COMMAND:
        {
            return Command(LOWORD(wParam), HIWORD(wParam));
        }
    }

    return DefProc(msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::DefProc
// -------------------------------------------------------------- //
LRESULT Win32::Dialog::ModalDialog::DefProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
    return FALSE;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Closed
// -------------------------------------------------------------- //
LRESULT Win32::Dialog::ModalDialog::Closed()
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Destroyed
// -------------------------------------------------------------- //
LRESULT Win32::Dialog::ModalDialog::Destroyed()
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::MsgProc
// -------------------------------------------------------------- //
INT_PTR CALLBACK Win32::Dialog::ModalDialog::MsgProc(HWND hwndDlg, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
    ModalDialog* modalDialog = NULL;

    if(uMsg == WM_INITDIALOG)
    {
        // store a handle with the window
        modalDialog = reinterpret_cast< ModalDialog* >(lParam);

#pragma warning(suppress: 4244) // shuts the compiler up in this case (nothing else can be done)
        ::SetWindowLongPtr(hwndDlg, DWLP_USER, reinterpret_cast< LONG_PTR >(modalDialog));
        modalDialog->m_Dlg = hwndDlg;
    }
    else
    {
        // grab the handle from the window
#pragma warning(suppress: 4312) // shuts the compiler up in this case (nothing else can be done)
        modalDialog = reinterpret_cast< ModalDialog* >(::GetWindowLongPtr(hwndDlg, DWLP_USER));
    }

    return modalDialog != NULL ? modalDialog->Switch(uMsg, wParam, lParam) : FALSE;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Create
// -------------------------------------------------------------- //
bool Win32::Dialog::ModalDialog::Create(const TCHAR* const resourceName, HWND parent)
{
    INT_PTR result = ::DialogBoxParam(GetApplication()->GetInstance(), resourceName, parent,
        (DLGPROC)Win32::Dialog::ModalDialog::MsgProc, reinterpret_cast< LPARAM >(this));

    return result != 0;
}

// -------------------------------------------------------------- //
// Win32::Dialog::ModalDialog::Create
// -------------------------------------------------------------- //
INT_PTR Win32::Dialog::ModalDialog::Command(WORD controlID, WORD msg)
{
    if(controlID  == IDOK || controlID == IDCANCEL)
    {
        ::EndDialog(m_Dlg, controlID);
    }

    return FALSE;
}

// -------------------------------------------------------------- //
//
/// \file Brush.h
/// \brief A win32 brush object wrapper
//
// -------------------------------------------------------------- //

#include "Win32/GDI/Brush.h"

// -------------------------------------------------------------- //
/// Win32::GDI::Brush::GetStockBrush
// -------------------------------------------------------------- //
HBRUSH Win32::GDI::Brush::GetStockBrush(StockBrush stockBrushType)
{
    return (HBRUSH)::GetStockObject((int)stockBrushType);
}

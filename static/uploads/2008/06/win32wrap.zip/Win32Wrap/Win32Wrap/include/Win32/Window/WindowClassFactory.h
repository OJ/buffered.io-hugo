// -------------------------------------------------------------- //
//
/// \file WindowClass.h
/// \brief Contains a class that is used as a central hub for creating
/// window class objects.
//
// -------------------------------------------------------------- //

#ifndef _WIN32WINDOWWINDOWCLASSFACTORY_H_
#define _WIN32WINDOWWINDOWCLASSFACTORY_H_

#include "Win32/Window/WindowClass.h"

namespace Win32
{

    namespace Window
    {

        /// \ingroup Win32Window
        /// \brief A class responsible for handling and producing
        /// window classes
        /// \remark Instead of having a collection of windows attempt
        /// to handle their own class and make sure that it's registered
        /// once and only once, the factory is there to make sure that
        /// it happens, and that there is a central location that allows
        /// easy access to the window class.
        class WindowClassFactory
        {

        public: /// \name Construction and destruction
            /// @{

            /// \brief Object constructor
            WindowClassFactory();

            /// \brief Object destructor
            ~WindowClassFactory();

            /// @}
        public: /// \name General functions
            /// @{

            /// \brief Get a handle to a particular window class
            /// \param className Name of the class to get a handle to
            /// \return WindowClass pointer
            /// \remark The function looks to see if the class is already
            /// created and returns a pointer to it if it is, otherwise it
            /// attempts to create the window class object, bind it to
            /// the class name and return a handle to it instead
            WindowClass* GetWindowClass(const TCHAR* const className);

            /// @}
        private: /// \name Typedefs and enums
            /// @{

            typedef std::map< const TCHAR* const, WindowClass* > WinClassMap;

            /// @}
        private: /// \name Functions
            /// @{

            /// \brief Clear out all the known classes
            /// \return None
            void Clear();

            /// @}
        private: /// \name Member variables
            /// @{

            /// \brief Container for the known window classes
            WinClassMap m_Classes;

            /// @}
        };

    }

}

#endif // _WIN32WINDOWWINDOWCLASSFACTORY_H_

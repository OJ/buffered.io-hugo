// -------------------------------------------------------------- //
//
/// \file Font.h
/// \brief A win32 brush object wrapper
//
// -------------------------------------------------------------- //

#include "Win32/GDI/Font.h"

// -------------------------------------------------------------- //
/// Win32::GDI::Font::GetStockFont
// -------------------------------------------------------------- //
HFONT Win32::GDI::Font::GetStockFont(StockFont stockFontType)
{
    return (HFONT)::GetStockObject((int)stockFontType);
}

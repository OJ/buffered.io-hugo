// -------------------------------------------------------------- //
//
/// \file Application.cpp
/// \brief A class that contains basic required functionality for
/// all Win32 Applications
//    
// -------------------------------------------------------------- //

#include "Win32/Application.h"
#include "Win32/Window/MDIParentWindow.h"
#include "Win32/Window/WindowClassFactory.h"

// -------------------------------------------------------------- //
// Win32::Application::Application
// -------------------------------------------------------------- //
Win32::Application::Application(HINSTANCE instance, int argc, TCHAR** argv)
: m_Instance(instance),
  m_Argc(argc),
  m_Argv(argv)
{}

// -------------------------------------------------------------- //
// Win32::Application::~Application
// -------------------------------------------------------------- //
Win32::Application::~Application()
{}

// -------------------------------------------------------------- //
// Win32::Application::MessagePump
// -------------------------------------------------------------- //
int Win32::Application::MessagePump() const
{
    using Win32::Window::Window;
    using Win32::Window::MDIParentWindow;

    MSG msg;
    BOOL result;

    // handle the case for MS's magic tri-state boolean! (it can be zero, -1, and non-zero!)
    // check out the following link for more information:
    // http://msdn.microsoft.com/library/default.asp?url=/library/en-us/winui/winui/windowsuserinterface/windowing/messagesandmessagequeues/messagesandmessagequeuesreference/messagesandmessagequeuesfunctions/getmessage.asp
    while((result = ::GetMessage(&msg, NULL, 0, 0)) != 0)
    {
        // make sure an error was not returned.
        if(result != -1)
        {
#pragma warning(suppress: 4312) // shuts the compiler up in this case (nothing else can be done)
            Window* win = reinterpret_cast<Window*>(::GetWindowLongPtr(msg.hwnd, GWLP_USERDATA));

            // make sure we don't have an MDI parent window because the Translate/Dispatch pair shouldn't be
            // called in that case when the MDI system accelerators aren't handled.
            if(!win || !(win->IsMDIParent() && ::TranslateMDISysAccel(reinterpret_cast< MDIParentWindow* >(win)->GetClientHandle(), &msg)))
            {
                ::TranslateMessage(&msg);
                ::DispatchMessage(&msg);
            }
        }
        else
        {
            /// \todo Show error.
            break;
        }
    }

    return msg.wParam == 0 ? 0 : 1;
}


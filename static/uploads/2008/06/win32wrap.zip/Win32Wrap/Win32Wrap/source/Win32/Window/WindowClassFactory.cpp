// -------------------------------------------------------------- //
//
/// \file WindowClassFactory.cpp
/// \brief Contains a class that is used as a central hub for creating
/// window class objects.
//
// -------------------------------------------------------------- //

#include "Win32/Window/WindowClassFactory.h"

// -------------------------------------------------------------- //
// Win32::Window::WindowClassFactory::WindowClassFactory
// -------------------------------------------------------------- //
Win32::Window::WindowClassFactory::WindowClassFactory(void)
{}

// -------------------------------------------------------------- //
// Win32::Window::WindowClassFactory::~WindowClassFactory
// -------------------------------------------------------------- //
Win32::Window::WindowClassFactory::~WindowClassFactory(void)
{
    Clear();
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClassFactory::GetWindowClass
// -------------------------------------------------------------- //
Win32::Window::WindowClass* Win32::Window::WindowClassFactory::GetWindowClass(const TCHAR* const className)
{
    WindowClass* wc = NULL;
    WinClassMap::iterator csr = m_Classes.find(className);

    if(csr != m_Classes.end())
    {
        wc = csr->second;
    }
    else
    {
        wc = new WindowClass(className);
        if(wc != NULL)
        {
            m_Classes.insert(WinClassMap::value_type(className, wc));
        }
    }

    return wc;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClassFactory::Clear
// -------------------------------------------------------------- //
void Win32::Window::WindowClassFactory::Clear(void)
{
    for(WinClassMap::iterator csr = m_Classes.begin(); csr != m_Classes.end(); ++csr)
    {
        WindowClass* wc = (WindowClass*)csr->second;
        delete csr->second;
    }
    m_Classes.clear();
}
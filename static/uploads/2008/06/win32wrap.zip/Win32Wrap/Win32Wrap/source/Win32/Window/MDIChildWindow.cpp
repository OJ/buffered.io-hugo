// -------------------------------------------------------------- //
//
/// \file MDIChildWindow.cpp
/// \brief Contains the definition for a generic MDI window object.
/// Any window that is MDI used in the system should inherit from this
/// window type.
//
// -------------------------------------------------------------- //

#include "Win32/Types.h"
#include "Win32/Application.h"
#include "Win32/Window/MDIChildWindow.h"
#include "Win32/Window/MDIParentWindow.h"
#include "Win32/Window/WindowClassFactory.h"

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::MDIChildWindow
// -------------------------------------------------------------- //
Win32::Window::MDIChildWindow::MDIChildWindow(Win32::Application* application)
: Window(application), m_Win(NULL), m_ParentWin(NULL)
{
    ::ZeroMemory(&m_CreateStruct, sizeof(m_CreateStruct));

    // set up some defaults
    m_CreateStruct.hOwner = application->GetInstance();
    m_CreateStruct.x = CW_USEDEFAULT;
    m_CreateStruct.y = CW_USEDEFAULT;
    m_CreateStruct.cx = CW_USEDEFAULT;
    m_CreateStruct.cy = CW_USEDEFAULT;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::~MDIChildWindow
// -------------------------------------------------------------- //
Win32::Window::MDIChildWindow::~MDIChildWindow()
{
    Destroy();
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Create
// -------------------------------------------------------------- //
bool Win32::Window::MDIChildWindow::Create(Window* parent)
{
    if(parent != NULL && parent->IsMDIParent())
    {
        m_ParentWin = dynamic_cast< MDIParentWindow* >(parent);

        // make sure our class is registered
        Win32::Window::WindowClassFactory* wcf = GetApplication()->GetWindowClassFactory();
        if(wcf->GetWindowClass(GetClassName())->IsRegistered())
        {
            m_CreateStruct.szClass = GetClassName();
            m_CreateStruct.lParam = reinterpret_cast< LPARAM >(this);
            m_CreateStruct.szTitle = m_Caption.c_str();

            HWND win = (HWND)::SendMessage(m_ParentWin->GetClientHandle(), WM_MDICREATE, 0, reinterpret_cast< LPARAM >(&m_CreateStruct));

            return win != NULL;
        }
    }

    // not registered so fail
    return false;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Switch
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIChildWindow::Switch(UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
    case WM_CREATE:
        {
            return Created((CREATESTRUCT*)lParam);
        }
    case WM_CLOSE:
        {
            return Closed();
        }
    case WM_DESTROY:
        {
            return Destroyed();
        }
    case WM_NCDESTROY:
        {
            ::SetWindowLongPtr(m_Win, GWLP_USERDATA, 0);
            m_Win = NULL;

            // due to the loveliness of windows, we have to have a custom message to inform the caller
            // that our child window is dead.
            ::PostMessage(m_ParentWin->GetHandle(), CWM_MDICHILDDESTROYED, 0, reinterpret_cast< LPARAM >(this));
            return FALSE;
        }
    }

    return ::DefMDIChildProc(m_Win, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Created
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIChildWindow::Created(CREATESTRUCT* cs)
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::DefProc
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIChildWindow::DefProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
    return ::DefMDIChildProc(m_Win, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Closed
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIChildWindow::Closed()
{
    Destroy();
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Destroyed
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIChildWindow::Destroyed()
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::MessageProc
// -------------------------------------------------------------- //
LRESULT CALLBACK Win32::Window::MDIChildWindow::MessageProc(HWND win, UINT msg, WPARAM wParam, LPARAM lParam)
{
    MDIChildWindow* window = NULL;

    if(msg == WM_NCCREATE)
    {
        // store a handle with the window (yucky casting, thank you Microsoft!)
        window = reinterpret_cast< MDIChildWindow* >(reinterpret_cast< MDICREATESTRUCT* >(reinterpret_cast< CREATESTRUCT* >(lParam)->lpCreateParams)->lParam);

#pragma warning(suppress: 4244) // shuts the compiler up in this case (nothing else can be done)
        ::SetWindowLongPtr(win, GWLP_USERDATA, reinterpret_cast< LONG_PTR >(window));
        window->m_Win = win;
    }
    else
    {
        // grab the handle from the window
#pragma warning(suppress: 4312) // shuts the compiler up in this case (nothing else can be done)
        window = reinterpret_cast< MDIChildWindow* >(::GetWindowLongPtr(win, GWLP_USERDATA));
    }

    return window != NULL ? window->Switch(msg, wParam, lParam) :
        ::DefMDIChildProc(win, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Destroy
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::Destroy()
{
    if(m_Win != NULL)
    {
        ::SendMessage(m_ParentWin->GetClientHandle(), WM_MDIDESTROY, reinterpret_cast< WPARAM >(m_Win), 0);
        m_Win = NULL;
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::GetHandle
// -------------------------------------------------------------- //
HWND Win32::Window::MDIChildWindow::GetHandle() const
{
    return m_Win;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::GetCaption
// -------------------------------------------------------------- //
Win32::TSTR Win32::Window::MDIChildWindow::GetCaption() const
{
    return m_Caption;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::GetLeft
// -------------------------------------------------------------- //
int Win32::Window::MDIChildWindow::GetLeft() const
{
    return m_CreateStruct.x;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::GetTop
// -------------------------------------------------------------- //
int Win32::Window::MDIChildWindow::GetTop() const
{
    return m_CreateStruct.y;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::GetWidth
// -------------------------------------------------------------- //
int Win32::Window::MDIChildWindow::GetWidth() const
{
    return m_CreateStruct.cx;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::GetHeight
// -------------------------------------------------------------- //
int Win32::Window::MDIChildWindow::GetHeight() const
{
    return m_CreateStruct.cy;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::SetCaption
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::SetCaption(const TCHAR* const caption)
{
    m_Caption = caption;

    if(m_Win != NULL)
    {
        ::SetWindowText(m_Win, caption);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::AddWinStyle
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::AddWinStyle(LONG style)
{
    m_CreateStruct.style |= style;

    if(m_Win != NULL)
    {
        ::SetWindowLongPtr(m_Win, GWL_STYLE, m_CreateStruct.style);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::RemoveWinStyle
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::RemoveWinStyle(LONG style)
{
    m_CreateStruct.style &= ~style;

    if(m_Win != NULL)
    {
        ::SetWindowLongPtr(m_Win, GWL_STYLE, m_CreateStruct.style);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::AddExtWinStyle
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::AddExtWinStyle(LONG style)
{}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::SetIcon
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::SetIcon(HICON icon)
{
    ::SendMessage(m_Win, WM_SETICON, ICON_BIG, (LPARAM)icon);
    ::SendMessage(m_Win, WM_SETICON, ICON_SMALL, (LPARAM)icon);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::SetLeft
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::SetLeft(int left)
{
    MoveTo(left, m_CreateStruct.y);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::SetTop
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::SetTop(int top)
{
    MoveTo(m_CreateStruct.x, top);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::SetWidth
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::SetWidth(int width)
{
    Resize(width, m_CreateStruct.cy);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::SetHeight
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::SetHeight(int height)
{
  Resize(m_CreateStruct.cx, height);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::MoveTo
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::MoveTo(int left, int top)
{
  m_CreateStruct.x = left;
  m_CreateStruct.y = top;

  if(m_Win != NULL)
  {
    ::SetWindowPos(m_Win, NULL, left, top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
  }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Resize
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::Resize(int width, int height)
{
  m_CreateStruct.cx = width;
  m_CreateStruct.cy = height;

  if(m_Win != NULL)
  {
    ::SetWindowPos(m_Win, NULL, 0, 0, width, height, SWP_NOMOVE | SWP_NOZORDER);
  }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Show
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::Show()
{
  ::ShowWindow(m_Win, SW_SHOW);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Hide
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::Hide()
{
  ::ShowWindow(m_Win, SW_HIDE);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Minimise
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::Minimise()
{
  ::ShowWindow(m_Win, SW_MINIMIZE);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Maximise
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::Maximise()
{
  ::SendMessage(m_ParentWin->GetClientHandle(), WM_MDIMAXIMIZE, reinterpret_cast< WPARAM >(m_Win), 0);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Close
// -------------------------------------------------------------- //
void Win32::Window::MDIChildWindow::Close()
{
  ::SendMessage(m_Win, WM_CLOSE, 0, 0);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIChildWindow::Command
// -------------------------------------------------------------- //
bool Win32::Window::MDIChildWindow::Command(WORD controlID, WORD msg)
{
  return false;
}

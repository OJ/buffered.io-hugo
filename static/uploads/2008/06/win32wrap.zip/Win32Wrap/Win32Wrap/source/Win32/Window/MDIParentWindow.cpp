// -------------------------------------------------------------- //
//
/// \file MDIParentWindow.cpp
/// \brief Contains the definition for a generic MDI window object.
/// Any window that is MDI used in the system should inherit from this
/// window type.
//
// $History: $
//    
// -------------------------------------------------------------- //

#include "Win32/Types.h"
#include "Win32/Application.h"
#include "Win32/Window/MDIParentWindow.h"
#include "Win32/Window/WindowClassFactory.h"

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::MDIParentWindow
// -------------------------------------------------------------- //
Win32::Window::MDIParentWindow::MDIParentWindow(Win32::Application* application)
: Window(application),
  m_Win(NULL),
  m_ParentWin(NULL),
  m_WinStyles(NULL),
  m_ExtWinStyles(NULL),
  m_Left(CW_USEDEFAULT),
  m_Top(CW_USEDEFAULT),
  m_Width(CW_USEDEFAULT),
  m_Height(CW_USEDEFAULT)
{}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::~MDIParentWindow
// -------------------------------------------------------------- //
Win32::Window::MDIParentWindow::~MDIParentWindow ()
{
    Destroy();
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Create
// -------------------------------------------------------------- //
bool Win32::Window::MDIParentWindow::Create(Window* parent)
{
    // make sure our class is registered
    Win32::Window::WindowClassFactory* wcf = GetApplication()->GetWindowClassFactory();
    if(wcf->GetWindowClass(GetClassName())->IsRegistered())
    {
        if(parent != NULL)
        {
            m_ParentWin = parent->GetHandle();
        }

        HWND win = ::CreateWindowEx(m_ExtWinStyles, GetClassName(), m_Caption.c_str(),
            m_WinStyles, m_Left, m_Top, m_Width, m_Height, m_ParentWin, NULL,
            GetApplication()->GetInstance(), reinterpret_cast<LPVOID>(this));

        return win != NULL;
    }

    // not registered so fail
    return false;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetMDIMenu
// -------------------------------------------------------------- //
HMENU Win32::Window::MDIParentWindow::GetMDIMenu()
{
    // default to no menu
    return NULL;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetFirstChildID
// -------------------------------------------------------------- //
UINT Win32::Window::MDIParentWindow::GetFirstChildID()
{
    // give a default value that isn't going to hurt!
    return 5000;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Switch
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIParentWindow::Switch(UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
    case WM_CREATE:
        {
            return Created((CREATESTRUCT*)lParam);
        }
    case WM_CLOSE:
        {
            return Closed();
        }
    case WM_DESTROY:
        {
            return Destroyed();
        }
    case CWM_MDICHILDDESTROYED:
        {
            return ChildDestroyed(reinterpret_cast<MDIChildWindow*>(lParam));
        }
    case WM_NCDESTROY:
        {
            if(m_ClientWin != NULL)
            {
                ::DestroyWindow(m_ClientWin);
                m_ClientWin = NULL;
            }

            ::SetWindowLongPtr(m_Win, GWLP_USERDATA, 0);
            m_Win = NULL;
            break;
        }
    case WM_COMMAND:
        {
            Command(LOWORD(wParam), HIWORD(wParam));
            break;
        }
    }

    return ::DefFrameProc(m_Win, m_ClientWin, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Created
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIParentWindow::Created(CREATESTRUCT* cs)
{
    return(0);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::DefProc
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIParentWindow::DefProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
    return ::DefFrameProc(m_Win, m_ClientWin, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Closed
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIParentWindow::Closed()
{
    Destroy();
    return(0);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Destroyed
// -------------------------------------------------------------- //
LRESULT Win32::Window::MDIParentWindow::Destroyed()
{
    return(0);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::MessageProc
// -------------------------------------------------------------- //
LRESULT CALLBACK Win32::Window::MDIParentWindow::MessageProc(HWND win, UINT msg, WPARAM wParam, LPARAM lParam)
{
    MDIParentWindow* window = NULL;

    if(msg == WM_NCCREATE)
    {
        // store a handle with the window (yucky casting, thank you Microsoft!)
        window = reinterpret_cast<MDIParentWindow*>(reinterpret_cast<CREATESTRUCT*>(lParam)->lpCreateParams);

#pragma warning(suppress: 4244) // shuts the compiler up in this case (nothing else can be done)
        ::SetWindowLongPtr(win, GWLP_USERDATA, (LONG_PTR)window);
        window->m_Win = win;

        CLIENTCREATESTRUCT ccs;
        ccs.hWindowMenu = window->GetMDIMenu();
        ccs.idFirstChild = window->GetFirstChildID();

        window->m_ClientWin = ::CreateWindow(_T("MDICLIENT"), NULL,
            WS_CHILD | WS_CLIPCHILDREN | WS_VSCROLL | WS_HSCROLL,
            0, 0, 0, 0, win, NULL/*(HMENU) 0xCAC*/, window->GetApplication()->GetInstance(), (LPSTR)&ccs);
        ::ShowWindow(window->m_ClientWin, SW_SHOW);
    }
    else
    {
        // grab the handle from the window
#pragma warning(suppress: 4312) // shuts the compiler up in this case (nothing else can be done)
        window = reinterpret_cast<MDIParentWindow*>(::GetWindowLongPtr(win, GWLP_USERDATA));
    }

    return window != NULL ? window->Switch(msg, wParam, lParam) : ::DefFrameProc(win, ::GetWindow(win, GW_CHILD), msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Destroy
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::Destroy()
{
    if(m_Win != NULL)
    {
        ::DestroyWindow(m_Win);
        m_Win = NULL;
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetHandle
// -------------------------------------------------------------- //
HWND Win32::Window::MDIParentWindow::GetHandle() const
{
    return m_Win;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetCaption
// -------------------------------------------------------------- //
Win32::TSTR Win32::Window::MDIParentWindow::GetCaption() const
{
    return m_Caption;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetLeft
// -------------------------------------------------------------- //
int Win32::Window::MDIParentWindow::GetLeft() const
{
    return m_Left;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetTop
// -------------------------------------------------------------- //
int Win32::Window::MDIParentWindow::GetTop() const
{
    return m_Top;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetWidth
// -------------------------------------------------------------- //
int Win32::Window::MDIParentWindow::GetWidth() const
{
    return m_Width;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::GetHeight
// -------------------------------------------------------------- //
int Win32::Window::MDIParentWindow::GetHeight() const
{
    return m_Height;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::IsMDIParent
// -------------------------------------------------------------- //
bool Win32::Window::MDIParentWindow::IsMDIParent() const
{
    return true;
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::SetCaption
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::SetCaption(const TCHAR* const caption)
{
    m_Caption = caption;

    if(m_Win != NULL)
    {
        ::SetWindowText(m_Win, caption);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::AddWinStyle
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::AddWinStyle(LONG style)
{
    m_WinStyles |= style;

    if(m_Win != NULL)
    {
        ::SetWindowLongPtr(m_Win, GWL_STYLE, m_WinStyles);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::RemoveWinStyle
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::RemoveWinStyle(LONG style)
{
    m_WinStyles &= ~style;

    if(m_Win != NULL)
    {
        ::SetWindowLongPtr(m_Win, GWL_STYLE, m_WinStyles);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::AddExtWinStyle
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::AddExtWinStyle(LONG style)
{
  m_ExtWinStyles |= style;

  if(m_Win != NULL)
  {
    ::SetWindowLongPtr(m_Win, GWL_EXSTYLE, m_ExtWinStyles);
  }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::SetIcon
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::SetIcon(HICON icon)
{
  ::SendMessage(m_Win, WM_SETICON, ICON_BIG, (LPARAM)icon);
  ::SendMessage(m_Win, WM_SETICON, ICON_SMALL, (LPARAM)icon);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::SetLeft
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::SetLeft(int left)
{
  MoveTo(left, m_Top);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::SetTop
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::SetTop(int top)
{
  MoveTo(m_Left, top);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::SetWidth
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::SetWidth(int width)
{
  Resize(width, m_Height);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::SetHeight
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::SetHeight(int height)
{
  Resize(m_Width, height);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::MoveTo
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::MoveTo(int left, int top)
{
  m_Left = left;
  m_Top = top;

  if(m_Win != NULL)
  {
    ::SetWindowPos(m_Win, NULL, left, top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
  }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Resize
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::Resize(int width, int height)
{
  m_Width = width;
  m_Height = height;

  if(m_Win != NULL)
  {
    ::SetWindowPos(m_Win, NULL, 0, 0, width, height, SWP_NOMOVE | SWP_NOZORDER);
  }
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Show
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::Show()
{
  ::ShowWindow(m_Win, SW_SHOW);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Hide
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::Hide()
{
  ::ShowWindow(m_Win, SW_HIDE);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Minimise
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::Minimise()
{
  ::ShowWindow(m_Win, SW_MINIMIZE);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Maximise
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::Maximise()
{
  ::ShowWindow(m_Win, SW_MAXIMIZE);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Close
// -------------------------------------------------------------- //
void Win32::Window::MDIParentWindow::Close()
{
  ::SendMessage(m_Win, WM_CLOSE, 0, 0);
}

// -------------------------------------------------------------- //
// Win32::Window::MDIParentWindow::Command
// -------------------------------------------------------------- //
bool Win32::Window::MDIParentWindow::Command(WORD controlID, WORD msg)
{
  return false;
}

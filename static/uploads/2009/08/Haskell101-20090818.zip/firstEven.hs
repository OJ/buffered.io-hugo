first :: (a -> Bool) -> [a] -> Maybe a
first _ [] = Nothing
first f (x:xs) | f x = Just x
               | otherwise = first f xs

firstEven :: [Int] -> Maybe Int
firstEven = first even

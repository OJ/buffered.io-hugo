dub :: Double -> Double
dub = (*2)


// -------------------------------------------------------------- //
//
/// \file WindowClass.h
/// \brief Contains the declaration for a class that looks after
/// windows classes in Win32. Each window type needs to be registered
/// and this window class will handle the registration
//
// -------------------------------------------------------------- //

#ifndef _WIN32WINDOWWINDOWCLASS_H_
#define _WIN32WINDOWWINDOWCLASS_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Win32/Window/SDIWindow.h"
#include "Win32/Window/MDIParentWindow.h"
#include "Win32/Window/MDIChildWindow.h"
#include "Win32/GDI/Brush.h"

namespace Win32
{

    namespace Window
    {

        /// \ingroup Win32Window
        /// \brief Class designed to wrap functionality for the windows
        /// classes (a Win32-specific functionality).
        /// \remark Before a window can be created its class must be registered
        /// with the operating system - this class is designed to handle
        /// registration and unregistration of such windows classes.
        class WindowClass
        {

        public: /// \name Typedefs and enums
            /// @{

            /// \brief Typedef that specifies the class of window that will
            /// be created.
            typedef enum WindowType
            {
                /// A plain "Single Document Interface" window
                WT_SDI,
                /// A "Multiple Document Interface" parent/container window
                WT_MDIPARENT,
                /// A "Multiple Document Interface" child window
                WT_MDICHILD
            };

            /// @}
        public: /// \name Construction and Destruction
            /// @{

            /// \brief Object constructor
            /// \param className Name of the window class that this object
            /// will handle
            inline WindowClass(const TCHAR* const className);

            /// \brief Object destructor
            inline ~WindowClass();

            /// @}
        public: /// \name Registration functions
            /// @{

            /// \brief Register the window
            /// \return \c true indicates successful creation, \c false otherwise.
            /// \remark The window type must be registered before it can be used,
            /// this function provides the functionality to register the window
            /// type with the operating system.
            inline bool Register();

            /// \brief Unregister a registered window type
            /// \return \c true indicates succes, \c false otherwise
            /// \remark Unregistering a window isn't necessary, but it's a good idea.
            /// When finished with a particular window type, call this function to
            /// unregister it.
            inline bool Unregister();

            /// @}
        public: /// \name Access functions
            /// @{

            /// \brief Determine if the class has been registered
            /// \return \c true indicates yes, \c false otherwise
            inline bool IsRegistered() const;

            /// @}
        public: /// \name Manipulation functions
            /// @{

            /// \brief Set the type of window this class is
            /// \param wt The type of window that's going to be created from
            /// this class.
            inline void SetType(WindowType wt);

            /// \brief Add a style to the window class
            /// \param style The style to add to the class styles
            inline void AddStyle(LONG style);

            /// \brief Remove a style from the window class
            /// \param style Style to remove
            inline void RemoveStyle(LONG style);

            /// \brief Set the icon for the class.
            /// \param icon Handle to the icon.
            inline void SetIcon(HICON icon);

            /// \brief Set the menu for the class.
            /// \param menuName Resource name of the menu to be generated for each window.
            inline void SetMenu(const TCHAR* const menuName);

            /// \brief Set the cursor for the class
            /// \param cursor Handle to the cursor
            inline void SetCursor(HCURSOR cursor);

            /// \brief Set the brush used for the background of windows that will
            /// be generated based on this class
            /// \param bgBrush Handle to the brush
            inline void SetBackgroundBrush(HBRUSH bgBrush);

            /// @}
        private: /// \name Illegal functions
            /// @{

            /// \brief This function is illegal
            WindowClass(const WindowClass& wc);

            /// \brief This function is illegal
            WindowClass& operator=(const WindowClass& wc);

            /// @}
        private: /// \name Member variables
            /// @{

            /// \brief Handle to the class information structure
            WNDCLASSEX m_WcEx;

            /// \brief Handle to the class's atom (from registration)
            ATOM m_ClassAtom;

            /// \brief The Type of window (default is WT_SDI);
            WindowType m_WinType;

            /// @}
        };

    }

}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::WindowClass
// -------------------------------------------------------------- //
inline Win32::Window::WindowClass::WindowClass(const TCHAR* const className)
: m_ClassAtom(NULL),
  m_WinType(WT_SDI)
{
    using Win32::GDI::Brush;

    ::ZeroMemory(&m_WcEx, sizeof(m_WcEx));
    m_WcEx.cbSize = sizeof(m_WcEx);
    m_WcEx.lpszClassName = className;

    // set up some defaults
    m_WcEx.hbrBackground = Brush::GetStockBrush(Brush::SB_WHITE);
    m_WcEx.hCursor = (HCURSOR)::LoadCursor(NULL, IDC_ARROW);

    // use the standard SDI message proc for deafult
    m_WcEx.lpfnWndProc = (WNDPROC)Win32::Window::SDIWindow::MessageProc;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::~WindowClass
// -------------------------------------------------------------- //
inline Win32::Window::WindowClass::~WindowClass(void)
{
    Unregister();
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::Register
// -------------------------------------------------------------- //
inline bool Win32::Window::WindowClass::Register(void)
{
    if(m_ClassAtom == NULL)
    {
        m_ClassAtom = ::RegisterClassEx(&m_WcEx);
    }
    return m_ClassAtom != NULL;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::Unregister
// -------------------------------------------------------------- //
inline bool Win32::Window::WindowClass::Unregister(void)
{
    if(m_ClassAtom != NULL && ::UnregisterClass(m_WcEx.lpszClassName, m_WcEx.hInstance))
    {
        m_ClassAtom = NULL;
    }
    return m_ClassAtom == NULL;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::IsRegistered
// -------------------------------------------------------------- //
inline bool Win32::Window::WindowClass::IsRegistered(void)   const
{
    return m_ClassAtom != NULL;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::SetType
// -------------------------------------------------------------- //
inline void Win32::Window::WindowClass::SetType(WindowType wt)
{
    m_WinType = wt;

    if(wt == WT_SDI)
    {
        // use the standard SDI message proc
        m_WcEx.lpfnWndProc = (WNDPROC)Win32::Window::SDIWindow::MessageProc;
    }
    else if(wt == WT_MDIPARENT)
    {
        // use the MDI parent message proc
        m_WcEx.lpfnWndProc = (WNDPROC)Win32::Window::MDIParentWindow::MessageProc;
    }
    else // wt == WT_MDICHILD)
    {
        // use the MDI parent message proc
        m_WcEx.lpfnWndProc = (WNDPROC)Win32::Window::MDIChildWindow::MessageProc;
    }
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::AddStyle
// -------------------------------------------------------------- //
inline void Win32::Window::WindowClass::AddStyle(LONG style)
{
    m_WcEx.style |= style;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::RemoveStyle
// -------------------------------------------------------------- //
inline void Win32::Window::WindowClass::RemoveStyle(LONG style)
{
    m_WcEx.style &= ~style;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::SetIcon
// -------------------------------------------------------------- //
inline void Win32::Window::WindowClass::SetIcon(HICON icon)
{
    m_WcEx.hIcon = m_WcEx.hIconSm = icon;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::SetMenu
// -------------------------------------------------------------- //
inline void Win32::Window::WindowClass::SetMenu(const TCHAR* const menuName)
{
    m_WcEx.lpszMenuName = menuName;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::SetCursor
// -------------------------------------------------------------- //
inline void Win32::Window::WindowClass::SetCursor(HCURSOR cursor)
{
    m_WcEx.hCursor = cursor;
}

// -------------------------------------------------------------- //
// Win32::Window::WindowClass::SetBackgroundBrush
// -------------------------------------------------------------- //
inline void Win32::Window::WindowClass::SetBackgroundBrush(HBRUSH bgBrush)
{
    m_WcEx.hbrBackground = bgBrush;
}

#endif // _WIN32WINDOWWINDOWCLASS_H_

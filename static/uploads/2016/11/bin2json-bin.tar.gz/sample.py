#!/usr/bin/env python

# Very simple example of how to talk to the S.H.I.T. translation service

import socket, struct

def p32(v):
  return struct.pack('<L', v)

def p8(v):
  return struct.pack('B', v)

NAME_SIZE = 512
HANDLE_SIZE = 256

HACKER = 0
ENGINEER = 1
MANAGER = 2

CREATE = 0
PRINT = 1

TAIL = 0
HEAD = 1

hacker = ''
hacker += p32(HACKER)
hacker += 'Rob Fuller'.ljust(NAME_SIZE, '\x00')
hacker += p32(10)
hacker += 'Mubix'.ljust(HANDLE_SIZE, '\x00')

manager = ''
manager += p32(MANAGER)
manager += 'Larry Ellison'.ljust(NAME_SIZE, '\x00')
manager += p32(100000)

actions = ''

actions += p8(CREATE)
actions += p8(TAIL)
actions += hacker

actions += p8(CREATE)
actions += p8(HEAD)
actions += manager

actions += p8(PRINT)

payload = p32(len(actions)) + actions

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect(('127.0.0.1', 1337))
s.send(payload)
print s.recv(1024)
s.close()


// -------------------------------------------------------------- //
//
/// \file Window.h
/// \brief Contains the declaration for a generic window object.
/// Any window that is used in the system should inherit from this
/// window type
//    
// -------------------------------------------------------------- //

#ifndef _WIN32WINDOWWINDOW_H_
#define _WIN32WINDOWWINDOW_H_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Win32/Types.h"

namespace Win32
{

    namespace Window
    {

        /// \ingroup Win32Window
        /// \brief Class that is a generic wrapper for window object.
        /// \remark The class contains a collection of functions that
        /// are functional for all types of windows. Any window objects
        /// that are to be created as part of the system should inherit
        /// from this class and overload the required functionality
        class Window
        {

            // mention that the WindowClass object is a friend so that it
            // can change the message proc depending on the type of window
            friend class Win32::Window::WindowClass;

        public: /// \name Destruction and cleanup
            /// @{

            /// \brief Object destructor.
            virtual ~Window() {}

            /// \brief Destroy the window
            /// \return None.
            /// \remark This function should be called when the window is to
            /// be destroyed
            virtual void Destroy() = 0;

            /// @}
        public: /// \name Creation and initialisation
            /// @{

            /// \brief Create the window
            /// \param parent Handle to the parent window. \c NULL means no parent.
            /// The default parameter is \c NULL.
            /// \return \c true indicates successful creation, \c false otherwise.
            /// \remark The function uses the current style, extended style and
            /// classname to create the window
            bool Create(Window* parent = NULL);

            /// @}
        public: /// \name Access functions
            /// @{

            /// \brief Get a handle to the window
            /// \return HWND handle to current window
            virtual HWND GetHandle() const = 0;

            /// \brief Get the current caption/window text
            /// \return TSTR object containing text
            virtual TSTR GetCaption() const = 0;

            /// \brief Get the X coordinate of the left hand side of the window
            /// \return X coordinate
            virtual int GetLeft() const = 0;

            /// \brief Get the Y coordinate of the top side of the window
            /// \return Y coordinate
            virtual int GetTop() const = 0;

            /// \brief Get the width of the window
            /// \return Window width
            virtual int GetWidth() const = 0;

            /// \brief Get the height of the window
            /// \return Window height
            virtual int GetHeight() const = 0;

            /// \brief Determine if the window is an MDI parent
            /// \return \c true = MDI parent, \c false otherwise
            /// \remark This is used to check for MDI parent windows
            /// in the main message pump procedure.
            virtual bool IsMDIParent() const { return false; }

            /// @}
        public: /// \name Set functions
            /// @{

            /// \brief Set the caption of the window
            /// \param caption Text to apply to the caption
            /// \return None
            /// \remark The caption is stored in a member variable, and if the
            /// window currently exists the text is applied to the window as well.
            /// Otherwise it's used as a parameter to the window creation function.
            virtual void SetCaption(const TCHAR* const caption) = 0;

            /// \brief Add a style to the window
            /// \param style Style to add to the window
            /// \return None
            /// \remark Style is stored as a member variable and is applied to the
            /// window if the window already exists. Otherwise, it's used as a
            /// parameter in the Creation of the window.
            virtual void AddWinStyle(LONG style) = 0;

            /// \brief Remove a style from the window
            /// \param style Style to remove from the window
            /// \return None
            virtual void RemoveWinStyle(LONG style) = 0;

            /// \brief Add an extended style to the window
            /// \param style Extended style to add to the window
            /// \return None
            /// \remark Style is stored as a member variable and is applied to the
            /// window if the window already exists. Otherwise, it's used as a
            /// parameter in the Creation of the window.
            virtual void AddExtWinStyle(LONG style) = 0;

            /// \brief Set the icon for the window
            /// \param icon Handle to the icon
            /// \return None
            /// \remark Store the handle to the icon in the class info structure
            /// and use this information when creating the window class.
            virtual void SetIcon(HICON icon) = 0;

            /// \brief Set the left (X coordinate) of the window
            /// \param left The new X coordinate
            /// \return None
            /// \remark Left coordinate of the window is changed, and the window
            /// is updated if it exists. Otherwise the value is used when the
            /// window is created
            virtual void SetLeft(int left) = 0;

            /// \brief Set the top (Y coordinate) of the window
            /// \param top The new Y coordinate
            /// \return None
            /// \remark Top coordinate of the window is changed, and the window
            /// is updated if it exists. Otherwise the value is used when the
            /// window is created
            virtual void SetTop(int top) = 0;

            /// \brief Set the width of the window
            /// \param width The new width
            /// \return None
            /// \remark The width of the window is changed, and the window
            /// is updated if it exists. Otherwise the value is used when the
            /// window is created
            virtual void SetWidth(int width) = 0;

            /// \brief Set the height of the window
            /// \param height The new height
            /// \return None
            /// \remark The height of the window is changed, and the window
            /// is updated if it exists. Otherwise the value is used when the
            /// window is created
            virtual void SetHeight(int height) = 0;

            /// @}
        public: /// \name Window manipulation functions
            /// @{

            /// \brief Move the window to the specified location
            /// \param left The new X coordinate of the top-left corner of the
            /// window
            /// \param top The new Y coordinate of the top-left corner of the
            /// window
            /// \return None
            /// \remark The values are stored in the window's member variables,
            /// and the window is updated if it is already created, otherwise the
            /// values are used on window creation
            virtual void MoveTo(int left, int top) = 0;

            /// \brief Resize the window
            /// \param width The new window width
            /// \param height The new window height
            /// \return None
            /// \remark The values are stored in the window's member variables,
            /// and the window is updated if it is already created, otherwise the
            /// values are used on window creation
            virtual void Resize(int width, int height) = 0;

            /// \brief Show the window in it's normal state
            /// \return None
            /// \remark This is the same as restoring the window.
            virtual void Show() = 0;

            /// \brief Hide the window
            /// \return None
            virtual void Hide() = 0;

            /// \brief Minimise the window
            /// \return None
            virtual void Minimise() = 0;

            /// \brief Maximise the window
            /// \return None
            virtual void Maximise() = 0;

            /// \brief Close the window
            /// \return None
            virtual void Close() = 0;

            inline Win32::Application* GetApplication()
            {
                return m_Application;
            }

            /// @}
        protected: /// \name Object Construction
            /// @{

            /// \brief Object constructor
            Window(Win32::Application* application)
                : m_Application(application)
            {}

            /// @}
        protected: /// \name Callback functions/handlers
            /// @{

            /// \brief Main message switch handler.
            /// \param msg Message that has been sent to the window
            /// \param wParam Word parameter associated with the window
            /// \param lParam Long parameter associated with the window
            /// \return Varies depending the message and the result of processing
            /// \remark This function can be overloaded in child classes if required,
            /// but if this happens then the child class must pass the message on
            /// to the window object so that normal handling can occur.
            virtual LRESULT Switch(UINT msg, WPARAM wParam, LPARAM lParam) = 0;

            /// \brief Callback for when the window has been created
            /// \param cs Pointer to the creation structure
            /// \return Result of processing - usually zero
            virtual LRESULT Created(CREATESTRUCT* cs) = 0;

            /// \brief Do the default processing for this kind of window
            /// \param msg Message that has been sent to the window
            /// \param wParam Word parameter associated with the window
            /// \param lParam Long parameter associated with the window
            /// \return Varies depending the message and the result of processing
            /// \remark This function exists because default processing will vary
            /// depending on the type of window (eg. SDI window, MDI window or dialog box)
            virtual LRESULT DefProc(UINT msg, WPARAM wParam, LPARAM lParam) = 0;

            /// \brief Callback for when the window has been closed
            /// \return Result of processing - usually zero
            /// \remark The default behaviour for the window when the closed
            /// message is received is to destroy the window. If the caller doesn't
            /// want this to happen they must overload this function and provide
            /// their own implementation.
            virtual LRESULT Closed() = 0;

            /// \brief Callback for when the window has been destroyed
            /// \return Result of processing - usually zero
            virtual LRESULT Destroyed() = 0;

            /// \brief Callback for commands
            /// \param controlID ID of the control sending the message.
            /// \param msg The message being sent.
            /// \return True if handled, false otherwise.
            virtual bool Command(WORD controlID, WORD msg) = 0;

            /// \brief Function that returns the name of the window's class
            /// \return Window class name
            virtual const TCHAR* const GetClassName() const = 0;

            /// @}
        private: /// \name Illegal functions
            /// @{

            /// \brief This function is not allowed to be used.
            Window(const Window& window);

            /// \brief This function is not allowed to be used.
            Window& operator=(const Window& window);

            /// @}
        private: /// \name Member variables
            /// @{

            Win32::Application* m_Application;

            /// @}
        };

    }

}

#endif // _WIN32WINDOWWINDOW_H_

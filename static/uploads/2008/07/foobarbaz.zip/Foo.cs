﻿namespace Foo
{
    public class Foo
    {
        private Bar.Bar _bar = new Bar.Bar();

        public string SecretMessage
        {
            get { return _bar.SecretMessage; }
        }
    }
}

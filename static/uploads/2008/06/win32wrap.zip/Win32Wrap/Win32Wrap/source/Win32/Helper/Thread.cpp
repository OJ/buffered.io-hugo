// -------------------------------------------------------------- //
//
/// \file Thread.cpp
/// \brief A class that contains functionality that makes it easier
/// to deal with windows threads.
//
// -------------------------------------------------------------- //

#include "Win32/Helper/Thread.h"

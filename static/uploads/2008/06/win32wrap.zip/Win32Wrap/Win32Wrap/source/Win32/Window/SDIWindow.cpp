// -------------------------------------------------------------- //
//
/// \file SDIWindow.cpp
/// \brief Contains the definition for a generic SDI window object.
/// Any window that is SDI used in the system should inherit from this
/// window type.
//
// -------------------------------------------------------------- //

#include "Win32/Application.h"
#include "Win32/Window/SDIWindow.h"
#include "Win32/Window/WindowClassFactory.h"

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::SDIWindow
// -------------------------------------------------------------- //
Win32::Window::SDIWindow::SDIWindow(Win32::Application* application)
: Window(application),
  m_Win(NULL),
  m_ParentWin(NULL),
  m_WinStyles(NULL),
  m_ExtWinStyles(NULL),
  m_Left(CW_USEDEFAULT),
  m_Top(CW_USEDEFAULT),
  m_Width(CW_USEDEFAULT),
  m_Height(CW_USEDEFAULT)
{}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::~SDIWindow
// -------------------------------------------------------------- //
Win32::Window::SDIWindow::~SDIWindow()
{
    Destroy();
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Create
// -------------------------------------------------------------- //
bool Win32::Window::SDIWindow::Create(Window* parent)
{
    // make sure our class is registered
    Win32::Window::WindowClassFactory* wcf = GetApplication()->GetWindowClassFactory();
    if(wcf->GetWindowClass(GetClassName())->IsRegistered())
    {
        if(parent != NULL)
        {
            m_ParentWin = parent->GetHandle();
        }

        HWND win = ::CreateWindowEx(m_ExtWinStyles, GetClassName(), m_Caption.c_str(),
            m_WinStyles, m_Left, m_Top, m_Width, m_Height, m_ParentWin, NULL,
            GetApplication()->GetInstance(), reinterpret_cast< LPVOID >(this));

        return win != NULL;
    }

    // not registered so fail
    return false;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Switch
// -------------------------------------------------------------- //
LRESULT Win32::Window::SDIWindow::Switch(UINT msg, WPARAM wParam, LPARAM lParam)
{
    switch(msg)
    {
    case WM_CREATE:
        {
            return Created((CREATESTRUCT*)lParam);
        }
    case WM_CLOSE:
        {
            return Closed();
        }
    case WM_DESTROY:
        {
            return Destroyed();
        }
    case WM_NCDESTROY:
        {
            ::SetWindowLongPtr(m_Win, GWLP_USERDATA, 0);
            m_Win = NULL;
            break;
        }
    }

    return ::DefWindowProc(m_Win, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Created
// -------------------------------------------------------------- //
LRESULT Win32::Window::SDIWindow::Created(CREATESTRUCT* cs)
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::DefProc
// -------------------------------------------------------------- //
LRESULT Win32::Window::SDIWindow::DefProc(UINT msg, WPARAM wParam, LPARAM lParam)
{
    return ::DefWindowProc(m_Win, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Closed
// -------------------------------------------------------------- //
LRESULT Win32::Window::SDIWindow::Closed()
{
    Destroy();
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Destroyed
// -------------------------------------------------------------- //
LRESULT Win32::Window::SDIWindow::Destroyed()
{
    return 0;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::MessageProc
// -------------------------------------------------------------- //
LRESULT CALLBACK Win32::Window::SDIWindow::MessageProc(HWND win, UINT msg, WPARAM wParam, LPARAM lParam)
{
    SDIWindow* window = NULL;

    if(msg == WM_NCCREATE)
    {
        // store a handle with the window
        window = reinterpret_cast< SDIWindow* >(reinterpret_cast< CREATESTRUCT* >(lParam)->lpCreateParams);

#pragma warning(suppress: 4244) // shuts the compiler up in this case (nothing else can be done)
        ::SetWindowLongPtr(win, GWLP_USERDATA, reinterpret_cast< LONG_PTR >(window));
        window->m_Win = win;
    }
    else
    {
        // grab the handle from the window
#pragma warning(suppress: 4312) // shuts the compiler up in this case (nothing else can be done)
        window = reinterpret_cast< SDIWindow* >(::GetWindowLongPtr(win, GWLP_USERDATA));
    }

    return window != NULL ? window->Switch(msg, wParam, lParam) : ::DefWindowProc(win, msg, wParam, lParam);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Destroy
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::Destroy()
{
    if(m_Win != NULL)
    {
        ::DestroyWindow(m_Win);
        m_Win = NULL;
    }
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::GetHandle
// -------------------------------------------------------------- //
HWND Win32::Window::SDIWindow::GetHandle() const
{
    return m_Win;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::GetCaption
// -------------------------------------------------------------- //
Win32::TSTR Win32::Window::SDIWindow::GetCaption() const
{
    return m_Caption;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::GetLeft
// -------------------------------------------------------------- //
int Win32::Window::SDIWindow::GetLeft() const
{
    return m_Left;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::GetTop
// -------------------------------------------------------------- //
int Win32::Window::SDIWindow::GetTop() const
{
    return m_Top;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::GetWidth
// -------------------------------------------------------------- //
int Win32::Window::SDIWindow::GetWidth() const
{
    return m_Width;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::GetHeight
// -------------------------------------------------------------- //
int Win32::Window::SDIWindow::GetHeight() const
{
    return m_Height;
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::SetCaption
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::SetCaption(const TCHAR* const caption)
{
    m_Caption = caption;

    if(m_Win != NULL)
    {
        ::SetWindowText(m_Win, caption);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::AddWinStyle
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::AddWinStyle(LONG style)
{
    m_WinStyles |= style;

    if(m_Win != NULL)
    {
        ::SetWindowLongPtr(m_Win, GWL_STYLE, m_WinStyles);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::RemoveWinStyle
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::RemoveWinStyle(LONG style)
{
    m_WinStyles &= ~style;

    if(m_Win != NULL)
    {
        ::SetWindowLongPtr(m_Win, GWL_STYLE, m_WinStyles);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::AddExtWinStyle
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::AddExtWinStyle(LONG style)
{
    m_ExtWinStyles |= style;

    if(m_Win != NULL)
    {
        ::SetWindowLongPtr(m_Win, GWL_EXSTYLE, m_ExtWinStyles);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::SetIcon
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::SetIcon(HICON icon)
{
    ::SendMessage(m_Win, WM_SETICON, ICON_BIG, (LPARAM)icon);
    ::SendMessage(m_Win, WM_SETICON, ICON_SMALL, (LPARAM)icon);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::SetLeft
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::SetLeft(int left)
{
    MoveTo(left, m_Top);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::SetTop
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::SetTop(int top)
{
    MoveTo(m_Left, top);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::SetWidth
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::SetWidth(int width)
{
    Resize(width, m_Height);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::SetHeight
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::SetHeight(int height)
{
    Resize(m_Width, height);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::MoveTo
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::MoveTo(int left, int top
                                      )
{
    m_Left = left;
    m_Top = top;

    if(m_Win != NULL)
    {
        ::SetWindowPos(m_Win, NULL, left, top, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Resize
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::Resize(int width, int height
                                      )
{
    m_Width = width;
    m_Height = height;

    if(m_Win != NULL)
    {
        ::SetWindowPos(m_Win, NULL, 0, 0, width, height, SWP_NOMOVE | SWP_NOZORDER);
    }
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Show
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::Show()
{
    ::ShowWindow(m_Win, SW_SHOW);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Hide
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::Hide()
{
    ::ShowWindow(m_Win, SW_HIDE);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Minimise
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::Minimise()
{
    ::ShowWindow(m_Win, SW_MINIMIZE);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Maximise
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::Maximise()
{
    ::ShowWindow(m_Win, SW_MAXIMIZE);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Close
// -------------------------------------------------------------- //
void Win32::Window::SDIWindow::Close()
{
    ::SendMessage(m_Win, WM_CLOSE, 0, 0);
}

// -------------------------------------------------------------- //
// Win32::Window::SDIWindow::Command
// -------------------------------------------------------------- //
bool Win32::Window::SDIWindow::Command(WORD controlID, WORD msg)
{
    return false;
}

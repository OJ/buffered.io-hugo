// -------------------------------------------------------------- //
//
/// \file Types.h
/// \brief Definitions and declarations of types that are used
/// throughout the program.
//
// -------------------------------------------------------------- //

#ifndef _WIN32TYPES_H_
#define _WIN32TYPES_H_

#if _MSC_VER > 1000
#pragma once
#pragma warning(disable: 4786)
#endif // _MSC_VER > 1000

#include <windows.h>
#include <list>
#include <deque>
#include <string>
#include <sstream>
#include <map>
#include <vector>
#include <tchar.h>

// Handy macros/helpers for debugging
#ifdef _DEBUG
#define _CRTDBG_MAP_ALLOC
#include <cstdlib> 
#include <crtdbg.h>
#include <cassert>
#define BREAKIF(x) if(x) { _CrtDbgBreak(); }
#define ASSERT(x) assert(x)
#else
#undef _CRTDBG_MAP_ALLOC
#define BREAKIF(x)
#define ASSERT(x)
#endif // _DEBUG

/// \brief Namespace that will contain all of the Win32 specific
/// classes and their functionality
namespace Win32
{

    /// \defgroup Win32HelperTypes Collection of types to make things eeeeeasy.
    /// @{

    /// \brief Standard ANSI string type.
    /// \remark This type should only ever be used when it is certain
    /// that it has to remain as an ANSI string even when compiled under
    /// unicode.
    typedef std::basic_string< char > ASTR;

    /// \brief Standard Wide-string type.
    /// \remark This type should only ever be used when it is certain that
    /// a unicode/wide string is required even when compiled under ANSI
    typedef std::basic_string< wchar_t > WSTR;

    /// \brief TCHAR string
    /// \remark String that varies in type depending on how the code is
    /// compiled. This should be used for all standard strings where
    /// unicode compatibility may be required.
    typedef std::basic_string< TCHAR > TSTR;

    /// \brief TCHAR string stream.
    /// \remark String stream that varies in type depending on if the
    /// code is compiled as unicode or not. This object should be used
    /// as a safe alternative to sprintf().
    typedef std::basic_stringstream< TCHAR > TSTRSTR;

    /// \brief Vector of TSTR objects.
    /// \remark Specified as a typedef as it's a commonly used type.
    typedef std::vector< TSTR > TSTRVEC;

    /// @}

    /// \defgroup Win32Application Collection of objects that deal with
    /// the general running of the application.
    /// @{

    class Application;

    /// @}

    /// \brief Namespace containing all of the common window objects.
    namespace Window
    {
        /// \defgroup Win32Window Collection of window objects.
        /// @{

        class Window;
        class SDIWindow;
        class MDIParentWindow;
        class MDIChildWindow;
        class WindowClass;
        class WindowClassFactory;

        /// @}

        /// \brief Collection of custom messages for windows.
        typedef enum CustomWindowMessage
        {
            /// \brief Indication that a child window has been destroyed.
            /// \remark WPARAM = 0, LPARAM = Pointer to MDI child.
            CWM_MDICHILDDESTROYED = WM_USER
        };

    }

    /// \brief Namespace containing all of the common dialog objects.
    namespace Dialog
    {

        /// \defgroup Win32Dialog Collection of dialog objects.
        /// @{

        class Dialog;
        class ModalDialog;
        class ModelessDialog;

        /// @{
    }

    /// \brief Namespace containing all of the helper and miscellaneous objects.
    namespace Helper
    {
        /// \defgroup Win32Helper Collection of helper/miscellaneous objects.
        /// @{

        class Rect;
        class Region;

        class Thread;

        template<class THREADCLASS, typename THREADFUNC>
        class TypedThread;

        /// @}
    }

    /// \brief Namespace containing all the GDI objects.
    namespace GDI
    {
        /// \defgroup Win32GDI Collection of GDI objects.
        /// @{

        class DC;
        class Brush;
        class Font;
        class MemoryDC;
        class Pen;

        /// @}
    }

    /// \brief Namespace containing all the Controls found in Win32.
    namespace CommonControls
    {
        /// \defgroup Win32CommonControls Collection of common control handling objects.
        /// @{

        class Menu;

        /// @}
    }

    /// \brief Namespace containing all IO classes.
    namespace IO
    {

        /// \defgroup Win32IO Collection of I/O related classes.
        /// @{

        class File;

        /// @}
    }

}

#endif // _WIN32TYPES_H_

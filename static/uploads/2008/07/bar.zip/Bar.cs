﻿namespace Bar
{
    public class Bar
    {
        public string SecretMessage
        {
            get { return "Slartibartfast"; }
        }
    }
}
